$(document).ready(function(){
    var table = $('table.scroll'),
        bodyCells = table.find('tbody tr:first').children(),
        colWidth;
    $(window).resize(function() {
        colWidth = bodyCells.map(function() {
            return $(this).width();
        }).get();
        table.find('thead tr').children().each(function(i, v) {
            $(v).width(colWidth[i]);
        });
    }).resize();
});
angular.module('dashboard', ['ui.router', 'ngSanitize', 'ngTouch', 'ngAnimate'])
    .config(function ($stateProvider, $urlRouterProvider) {
        $urlRouterProvider.otherwise('/home');
        $stateProvider
            .state('home', {
                url: '/home',
                templateUrl: 'templates/home.html',
                controller: 'homeController'
            })
            .state('myClients', {
                url: '/myClients',
                templateUrl: 'templates/myClients.html',
                controller: 'clientsController'
            })
            .state('allClients', {
                url: '/allClients',
                templateUrl: 'templates/allClients.html',
                controller: 'clientsController'
            })
            .state('reports', {
                url: '/reports',
                templateUrl: 'templates/reports.html',
                controller: 'reportsController'
            })
    })
    .run(function ($rootScope, $state) {
        $rootScope.$state = $state;
    });