angular.module('dashboard')
    .directive('monthlyProgressChart', function () {
        return {
            restrict: 'E',
            template: '<div id="monthlyProgress"></div>',
            controller: function () {
                var margin = {top: 20, right: 20, bottom: 36, left: 40},
                    width = $('#monthlyProgress').width() - margin.left - margin.right,
                    height = $('#monthlyProgress').width() - margin.top - margin.bottom - 70;
                var svg = d3.select("#monthlyProgress").append('svg').attr('height', height + margin.left + margin.right).attr('width', width + margin.top + margin.bottom);
                var g = svg.append("g").attr("transform", "translate(" + margin.left + "," + margin.top + ")");
                var x0 = d3.scaleBand()
                    .rangeRound([0, width])
                    .paddingInner(0.1);
                var x1 = d3.scaleBand()
                    .padding(.3);
                var y = d3.scaleLinear()
                    .rangeRound([height, 0]);
                var z = d3.scaleOrdinal()
                    .range(["rgb(59,175,42)", "rgb(59,175,42)"]);
                d3.csv("data/monthlyProgress.csv", function (d, i, columns) {
                    for (var i = 1, n = columns.length; i < n; ++i) d[columns[i]] = +d[columns[i]];
                    return d;
                }, function (error, data) {
                    if (error) throw error;
                    var keys = data.columns.slice(1);
                    x0.domain(data.map(function (d) {
                        return d.days;
                    }));
                    x1.domain(keys).rangeRound([0, x0.bandwidth()]);
                    y.domain([0, d3.max(data, function (d) {
                        return d3.max(keys, function (key) {
                            return d[key];
                        });
                    })]).nice();
                    g.append("g")
                        .selectAll("g")
                        .data(data)
                        .enter().append("g")
                        .attr("transform", function (d) {
                            return "translate(" + x0(d.days) + ",0)";
                        })
                        .selectAll("rect")
                        .data(function (d) {
                            return keys.map(function (key) {
                                return {key: key, value: d[key]};
                            });
                        })
                        .enter().append("rect")
                        .attr("x", function (d) {
                            return x1(d.key);
                        })
                        .attr("y", function (d) {
                            return y(d.value);
                        })
                        .attr("width", x1.bandwidth() + 3)
                        .attr("height", function (d) {
                            return height - y(d.value);
                        })
                        .attr("fill", function (d) {
                            return z(d.key);
                        });
                    g.append("g")
                        .attr("class", "axis")
                        .attr("transform", "translate(0," + height + ")")
                        .call(d3.axisBottom(x0));
                    g.append("g")
                        .attr("class", "axis")
                        .call(d3.axisLeft(y).ticks(null, "s"))
                        .append("text")
                        .attr("x", 2)
                        .attr("y", y(y.ticks().pop()) + 0.5)
                        .attr("dy", "0.32em")
                        .attr("fill", "#000")
                        .attr("font-weight", "bold")
                        .attr("text-anchor", "start");

                    $($('#monthlyProgress rect')[4]).attr('fill','rgb(19,93,130)');
                    $($('#monthlyProgress rect')[5]).attr('fill','rgb(19,93,130)');
                    $($('#monthlyProgress rect')[6]).attr('fill','rgb(19,93,130)');
                });
            }
        }
    });
