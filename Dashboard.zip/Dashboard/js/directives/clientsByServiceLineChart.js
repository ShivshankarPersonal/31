angular.module('dashboard')
    .directive('clientsByServiceLineChart', function () {
        return {
            restrict: 'E',
            template: '<div id="clientsByServiceLine"></div>',
            controller: function () {
                var margin = {top: 20, right: 20, bottom: 50, left: 40},
                    width = $('#clientsByServiceLine').width() - margin.left - margin.right,
                    height = $('#clientsByServiceLine').width() - margin.top - margin.bottom - 50;
                var x = d3.scaleBand()
                    .range([0, width])
                    .padding(0.5);
                var y = d3.scaleLinear()
                    .range([height, 0]);
                var svg = d3.select("#clientsByServiceLine").append("svg")
                    .attr("width", width + margin.left + margin.right)
                    .attr("height", height + margin.top + margin.bottom)
                    .append("g")
                    .attr("transform",
                        "translate(" + margin.left + "," + margin.top + ")");
                d3.csv("data/clientsByServiceLine.csv", function (error, data) {
                    if (error) throw error;
                    data.forEach(function (d) {
                        d.clients = +d.clients;
                    });
                    x.domain(data.map(function (d) {
                        return d.serviceLine;
                    }));
                    y.domain([0, d3.max(data, function (d) {
                        return d.clients;
                    })]);
                    svg.selectAll(".bar")
                        .data(data)
                        .enter().append("rect")
                        .attr("class", "bar")
                        .attr("x", function (d) {
                            return x(d.serviceLine);
                        })
                        .attr("width", x.bandwidth())
                        .attr("y", function (d) {
                            return y(d.clients);
                        })
                        .attr("height", function (d) {
                            return height - y(d.clients);
                        })
                        .style("fill", function (d) {
                            return "rgb(19,93,130)";
                        });
                    svg.append("g")
                        .attr("transform", "translate(0," + height + ")")
                        .call(d3.axisBottom(x));
                    svg.append("text")
                        .attr("transform",
                            "translate(" + (width / 2) + " ," +
                            (height + margin.top + 20) + ")")
                        .style("text-anchor", "middle")
                        .text("Service Line");
                    svg.append("g")
                        .call(d3.axisLeft(y));
                    svg.append("text")
                        .attr("transform", "rotate(-90)")
                        .attr("y", 0 - margin.left)
                        .attr("x", 0 - (height / 2))
                        .attr("dy", "1em")
                        .style("text-anchor", "middle")
                        .text("# of Clients");
                });
            }
        }
    });