angular.module("dashboard")
    .controller("clientsController", function ($scope, $state, dashboardFactory) {
        dashboardFactory.fetchData('allClients').then(function (data) {
            $scope.allClientsList = data;
        }, function (data) {
            console.error("Unable to Fetch Data"+data);
        });
        dashboardFactory.fetchData('myClients').then(function (data) {
            $scope.myClientsList = data;
        }, function (data) {
            console.error("Unable to Fetch Data"+data);
        });

        $('.myClientsGridContainer').slimScroll({
            height: '450px',
            width:'100%',
            horizontal:true
        });

    });